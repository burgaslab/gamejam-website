<?php

return array(
	"host" => "localhost",
	"database" => "burgasgamejam",
	"username" => "root",
	"password" => "",
);